export default {
  "trailingSlash": true,
  "pathPrefix": "",
  "titleTemplate": "%s - Cataingan Polytechnic Institute",
  "siteUrl": "https://gridsome-portfolio-starter.netlify.com",
  "version": "0.7.9"
}