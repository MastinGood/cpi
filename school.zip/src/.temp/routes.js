export default [
  {
    path: "/news/",
    component: () => import(/* webpackChunkName: "page--src-pages-news-vue" */ "D:\\xampp\\htdocs\\school\\src\\pages\\news.vue")
  },
  {
    path: "/about/",
    component: () => import(/* webpackChunkName: "page--src-pages-about-vue" */ "D:\\xampp\\htdocs\\school\\src\\pages\\about.vue")
  },
  {
    path: "/admission/",
    component: () => import(/* webpackChunkName: "page--src-pages-admission-vue" */ "D:\\xampp\\htdocs\\school\\src\\pages\\admission.vue")
  },
  {
    name: "404",
    path: "/404/",
    component: () => import(/* webpackChunkName: "page--src-pages-404-vue" */ "D:\\xampp\\htdocs\\school\\src\\pages\\404.vue")
  },
  {
    name: "home",
    path: "/",
    component: () => import(/* webpackChunkName: "page--src-pages-index-vue" */ "D:\\xampp\\htdocs\\school\\src\\pages\\Index.vue")
  },
  {
    name: "*",
    path: "*",
    component: () => import(/* webpackChunkName: "page--src-pages-404-vue" */ "D:\\xampp\\htdocs\\school\\src\\pages\\404.vue")
  }
]

